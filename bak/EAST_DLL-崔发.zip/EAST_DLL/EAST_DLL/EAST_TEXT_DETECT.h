#pragma once
#define dll_export __declspec(dllexport)

using namespace std;
using namespace cv::dnn;
using namespace cv;


 class dll_export EAST_TEXT_DETECT
{
public:
	int text_detect(const char* img_path, const char* model_path,  float confThreshold, float nmsThreshold,float Threshold, vector<vector<double> > &TextPos);
	
	void _decode_(const Mat &scores, const Mat &geometry, float Threshold, Mat &heibai);
private:
	
	static bool descendSort(std::vector<cv::Point> a, std::vector<cv::Point> b);
 };

