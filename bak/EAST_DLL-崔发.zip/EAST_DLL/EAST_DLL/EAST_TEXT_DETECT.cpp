#include "pch.h"
#include<iostream>
#include<fstream>
#include<opencv2/opencv.hpp>
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include "EAST_TEXT_DETECT.h"

using namespace std;
using namespace cv;
using namespace cv::dnn;


int EAST_TEXT_DETECT::text_detect(const char* img_path, const char* model_path, float confThreshold,
	float nmsThreshold, float Threshold, vector<vector<double> > &TextPos)
{
	int nRet = 0;

	try
	{	// ����ʵ��
		
		Net net = readNet(model_path);
		auto detect_image_path = img_path;    //"C:\\Users\\sl\\Desktop\\py.work\\OCR\\AdvancedEAST-master\\demo\\001.png";

		Mat srcImg = imread(detect_image_path);
		int or_h = srcImg.rows;
		int or_w = srcImg.cols;
	
		if (!srcImg.empty())
		{
			cout << "read image success!" << endl;
		}
	
		//���Ŷ���ֵ
		confThreshold = 0.5;
		//�Ǽ���ֵ�����㷨��ֵ
		nmsThreshold = 0.4;

		//���
		std::vector<Mat> output;
		std::vector<String> outputLayers(4);
		outputLayers[0] = "side_vertex_coord/convolution";
		outputLayers[1] = "side_vertex_code/convolution";
		outputLayers[2] = "inside_score/convolution";
		outputLayers[3] = "east_detect/concat";

		//���ͼ��
		Mat frame, blob;
		frame = srcImg.clone();
		//��ȡ���ѧϰģ�͵�����
		blobFromImage(frame, blob, 1.0, Size(640,  640), Scalar(123.68, 116.78, 103.94), true, false);
		net.setInput(blob);
		//������
		net.forward(output, outputLayers);

		//���Ŷ�
		Mat scores = output[3];
		//λ�ò���
		Mat geometry = output[0];

		// Decode predicted bounding boxes�� �Լ�����н��룬��ȡ�ı���λ�÷���
		//�ı���λ�ò���0
		Mat heibai( 160, 160, CV_8UC1);
	    _decode_(scores, geometry, Threshold, heibai);
		
		vector< vector< Point> > contours;  //���ڱ�������������Ϣ
		vector<Point> tempV;				//�ݴ������

		findContours(heibai, contours, RETR_EXTERNAL, CHAIN_APPROX_NONE);

		//�������������С������������
		
		sort(contours.begin(), contours.end(), descendSort);//��������
		vector<vector<Point> >::iterator itc = contours.begin();

		while (itc != contours.end())
		{
			int y = itc->size();
			if (itc->size() < 20)
			{
				itc = contours.erase(itc);
			}
			else
			{
				++itc;
			}
		}

		//draw
		Mat B;
		heibai.copyTo(B);
		drawContours(B, contours, -1, Scalar(150, 0, 0), FILLED);
		heibai = heibai - B;
		findContours(heibai, contours, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE, Point());
		heibai.copyTo(B);
		int i = 0;
		vector<vector<Point> >::iterator itr = contours.begin();
		int last_i = 0;
		for (int i = 0; i < contours.size(); i++)
		{
			Mat tmp(contours.at(i));
			Moments moment = moments(tmp, false);
			if (moment.m00 != 0)//��������Ϊ0
			{
				int x = cvRound(moment.m10 / moment.m00);//�������ĺ�����
				int y = cvRound(moment.m01 / moment.m00);//��������������
				if (x < 30 || y < 30 || x>120 || y>120)
				{
					vector< vector< Point> > contours2; //���ڱ����������100������
					for (int j = last_i; j < i; j++)
					{
						++itr;
					}
					last_i = i;
					contours2.push_back(*itr);
					drawContours(heibai, contours2, -1, Scalar(0, 0, 0), FILLED);
				}
			}

		}
		//heibai =  B- heibai;
		Mat element = getStructuringElement(MORPH_RECT, Size(3, 3));
		dilate(heibai, heibai, element);
		findContours(heibai, contours, RETR_EXTERNAL, CHAIN_APPROX_NONE);

		for (int i = 0; i < (int)contours.size(); i++)
		{
			RotatedRect rect = minAreaRect(contours[i]);
			Point2f fourPoint2f[4];
			rect.points(fourPoint2f);
			float ratio_h = (float)or_h / 640;
			float ratio_w = (float)or_w / 640;
			fourPoint2f[0].x = fourPoint2f[0].x * 4 * ratio_w;
			fourPoint2f[0].y = fourPoint2f[0].y * 4 * ratio_h;
			fourPoint2f[1].x = fourPoint2f[1].x * 4 * ratio_w;
			fourPoint2f[1].y = fourPoint2f[1].y * 4 * ratio_h;
			fourPoint2f[2].x = fourPoint2f[2].x * 4 * ratio_w;
			fourPoint2f[2].y = fourPoint2f[2].y * 4 * ratio_h;
			fourPoint2f[3].x = fourPoint2f[3].x * 4 * ratio_w;
			fourPoint2f[3].y = fourPoint2f[3].y * 4 * ratio_h;
			line(srcImg, fourPoint2f[0], fourPoint2f[1], Scalar(0, 255, 0), 2);
			line(srcImg, fourPoint2f[1], fourPoint2f[2], Scalar(0, 255, 0), 2);
			line(srcImg, fourPoint2f[2], fourPoint2f[3], Scalar(0, 255, 0), 2);
			line(srcImg, fourPoint2f[3], fourPoint2f[0], Scalar(0, 255, 0), 2);
			/*ofstream write;
			write.open("E://004.txt", ios::app);
			write << fourPoint2f[2].x << "," << fourPoint2f[2].y << "," << fourPoint2f[3].x << "," << fourPoint2f[3].y << "," << fourPoint2f[0].x << "," <<
				fourPoint2f[0].y << "," << fourPoint2f[1].x << "," << fourPoint2f[1].y << endl;
			write.close();*/

			
			double t[8] = { fourPoint2f[0].x ,fourPoint2f[0].y ,fourPoint2f[1].x ,fourPoint2f[1].y,fourPoint2f[2].x,fourPoint2f[2].y, fourPoint2f[3].x ,fourPoint2f[3].y };
			vector<double> b;
			b.clear();
				for (int i = 0; i <= 7; i++)
				{
					b.push_back(t[i]);
				}
			TextPos.push_back(b);
			
		
		}
		//cout << TextPos.size() << endl;
		//imshow("result", srcImg);
		//waitKey();
	}
	catch (...)
	{
		nRet = 1; //����쳣���

	}


	return nRet;
}

void EAST_TEXT_DETECT::_decode_(const Mat & scores, const Mat & geometry, float Threshold, Mat & heibai)
{
	const int height = geometry.size[2];
	const int width = geometry.size[3];
	for (int y = 0; y < height; y++)
	{
		//ʶ�����
		const float *isinside = scores.ptr<float>(0, 0, y);
		const float *isbound = scores.ptr<float>(0, 1, y);
		const float *headorwei = scores.ptr<float>(0, 2, y);
		const float *x_1 = geometry.ptr<float>(0, 0, y);
		const float *y_1 = geometry.ptr<float>(0, 1, y);
		const float *x_2 = geometry.ptr<float>(0, 2, y);
		const float *y_2 = geometry.ptr<float>(0, 3, y);
		//�������м�⵽�ļ���
		for (int x = 0; x < width; x++)
		{
			float isinside_1 = isinside[x];
			float isbound_1 = isbound[x];
			float headorwei_1 = headorwei[x];

			float x_11 = x_1[x];
			float y_11 = y_1[x];
			float x_22 = x_2[x];
			float y_22 = y_2[x];

			float offsetX = x * 4.0f, offsetY = y * 4.0f;
			//������ֵ���Ըü���

			if (isinside_1 < Threshold)
			{
				heibai.at<uchar>(y, x) = 0;
				continue;
			}
			//circle(srcImg, Point(offsetX, offsetY), 2, Scalar(0, 255, 0), -1);
			heibai.at<uchar>(y, x) = 255;

		}
	}
}

bool EAST_TEXT_DETECT::descendSort(vector<Point> a, vector<Point> b) {

	return a.size() > b.size();
}

